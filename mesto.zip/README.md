# Mesto
Страница создана с целью научиться основам JS.
## Стек
HTML, CSS, JavaScript, VSCode, LiveServer
## Как запустить проект?
1. Скопировать репозиторий:
```bash
git@github.com:RitaKruglova/mesto.git
```
2. Установить расширение LiveServer в VSCode.
3. Открыть index.html в корневой директории.
4. Запустить LiveServer.
5. Или перейти по ссылке https://ritakruglova.github.io/mesto/